const { Client, GatewayIntentBits, EmbedBuilder, Events } = require('discord.js');
const fs = require('fs');

const TOKEN = 'MTQyMzE2NjU5OTE4MzIwNDQwMw.GaKnhN.uK8J9pftPEkQvqhzsz39ozJyXV2iQTreXPdIoU';
const CHANNEL_ID = '1423164765219328124';

// Update this when you change the password
const CURRENT_PASSWORD = 'gPW4HMdqT9NZqnH4AXuwBd4SY';
const USERNAME = 'VaultHD';
const PASSWORD_FILE = './password.json';

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

// Read the last saved password
let lastPassword = null;
if (fs.existsSync(PASSWORD_FILE)) {
    const data = fs.readFileSync(PASSWORD_FILE, 'utf8');
    try {
        lastPassword = JSON.parse(data).password;
    } catch (err) {
        console.error('Error reading password file:', err);
    }
}

// Use the new 'clientReady' event to avoid the deprecation warning
client.once(Events.ClientReady, async () => {
    console.log(`Logged in as ${client.user.tag}`);

    // Only send embed if password has changed
    if (CURRENT_PASSWORD !== lastPassword) {
        try {
            const channel = await client.channels.fetch(CHANNEL_ID);
            if (!channel) return console.log('Channel not found');

            const embed = new EmbedBuilder()
                .setTitle('🔑 VaultHD Shared Login')
                .setDescription('Here are your VaultHD login credentials:')
                .addFields(
                    { name: 'Username', value: USERNAME, inline: false },
                    { name: 'Password', value: CURRENT_PASSWORD, inline: false }
                )
                .setColor(0x3498db)
                .setFooter({ text: 'Do not share this login with anyone outside the server!' });

            await channel.send({ embeds: [embed] });

            // Save the new password to file
            fs.writeFileSync(PASSWORD_FILE, JSON.stringify({ password: CURRENT_PASSWORD }, null, 2));
        } catch (err) {
            console.error('Failed to send embed:', err);
        }
    } else {
        console.log('Password has not changed — no message sent.');
    }
});

client.login(TOKEN);
